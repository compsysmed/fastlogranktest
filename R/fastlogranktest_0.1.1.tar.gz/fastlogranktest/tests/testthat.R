library(testthat)
library(fastlogranktest)

test_check("fastlogranktest")
