========
Usage
========

To use fastlogranktest in a project::

    import fastlogranktest
