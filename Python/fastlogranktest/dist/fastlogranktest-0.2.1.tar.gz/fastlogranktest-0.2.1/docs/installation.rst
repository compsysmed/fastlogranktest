============
Installation
============

At the command line::

    $ easy_install fastlogranktest

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv fastlogranktest
    $ pip install fastlogranktest
