=======
Credits
=======

Development Lead
----------------

* Andreas Stelzer <ga63nep@mytum.de>

* Manuela Lautizi <manuela.lautizi@wzw.tum.de>

* Tim Kacprowski <tim.kacprowski@wzw.tum.de>

* Research group of computational systems medicine Chair of Experimental Bioinformatics TU Munich 


Contributors
------------

None yet. Why not be the first?
