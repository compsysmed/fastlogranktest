.. :changelog:

History
-------

0.1.0 (2019-10-21)
---------------------

* First release on PyPI.

0.1.1 (2019-10-22)
---------------------

* Updated programm instructions.

0.1.2 (2019-11-05)
---------------------

* Updated programm instructions again.

0.1.3 (2019-11-05)
---------------------

* Updated link to gitlab.

0.1.4 (2019-11-07)
---------------------

* Improvements for Linux compatibility.

0.1.5 (2019-11-07)
---------------------

* Improvements for Linux compatibility.

0.1.6 (2019-11-07)
---------------------

* Improvements for Linux compatibility.

0.1.7 (2019-11-07)
---------------------

* Improvements for Linux compatibility.

0.1.8 (2019-11-07)
---------------------

* Improvements for Linux compatibility.

0.1.9 (2019-11-07)
---------------------

* Improvements for Linux compatibility.

0.2.0 (2019-02-01)
---------------------

* Updated installation and author information.